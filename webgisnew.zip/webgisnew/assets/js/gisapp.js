
// var map = new ol.Map({
//     target: 'map',
//     layers: [new ol.layer.Tile({
//         source: new ol.source.OSM()

//     })],
//     view: new ol.View({
//         //projection: 'EPSG:4326',
//         // center: ol.proj.fromLonLat([75.202 , -2.685]),
//         center: ol.proj.fromLonLat([114 , 0]),
//         zoom: 5
//     })
// });

// map.on('pointermove', (e) => {
//     var coor = ol.proj.toLonLat(e.coordinate);
//     //console.log(coor);
//     $('#coordinate').html(coor[0].toFixed(3) + " , " + coor[1].toFixed(3)); // e.coodinate.toString().replace(' ', ','));
// });

var iconFeature = new ol.Feature({
  geometry: new ol.geom.Point([114 , 0]), //This marker will not move.
  name: 'Somewhere',
});

var map = new ol.Map({
  target: 'map',
  layers: [
    new ol.layer.Tile({
      source: new ol.source.OSM(),
    }),
    // 
    
  ],
  view: new ol.View({
    center: ol.proj.fromLonLat([114 , 0]),
    zoom: 5
  })
});



//add marker
var markers = new ol.layer.Vector({
  source: new ol.source.Vector(),
  style: new ol.style.Style({
    image: new ol.style.Icon({
      anchor: [0.5, 1],
      src: 'https://geosat.co.id/wp-content/uploads/2020/06/icon_vassel.png'

    })
  })
});
map.addLayer(markers);

var marker = new ol.Feature(new ol.geom.Point(ol.proj.fromLonLat([104.731, -7.271])));
markers.getSource().addFeature(marker);


var marker2 = new ol.Feature(new ol.geom.Point(ol.proj.fromLonLat([112.73213, -7.22195])));
markers.getSource().addFeature(marker2);

//onclik

map.on('singleclick', function(evt) {
      marker.setPosition(evt.coordinate);

});

map.on('pointermove', (e) => {
    var coor = ol.proj.toLonLat(e.coordinate);
    //console.log(coor);
   $('#coordinate').html(coor[0].toFixed(3) + " , " + coor[1].toFixed(3)); // e.coodinate.toString().replace(' ', ','));
});

document.getElementById("demo").innerHTML = "Hello JavaScript";