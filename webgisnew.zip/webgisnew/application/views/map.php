<div class="row">
    <div class="col-md-4 shadow" style="padding:5px; border-radius:5px;">
        <div class="card md-2">
            <h4 class="card-header">Koordinat Kursor</h4>            
            <div class="card-body">
                <span id="coordinate"></span>
            </div>
        </div>
        <div class="card mb-2" style="margin-top:10px;">
            <h5 class="card-header">Informasi</h5>
            <div class="card-body">

            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="mapcanvas" id="map">
            
            </div>   
        </div>
    </div>
</div>